package com.pixeltrice.springbootQRcodegeneratorapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootQrCodeGeneratorAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootQrCodeGeneratorAppApplication.class, args);
	}

}
